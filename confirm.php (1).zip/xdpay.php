<?php
    /**
     * Class implimentaion for xdpay gateway
     */
    class Xdpay {
        static $TEST_CHANNEL = "101";
        
        // collection channels (pay)
        static $INDIAN_COLLECTION_CHANNEL = "27501";
        
        // payment channels (withdraw)
        static $INDIAN_PAYMENT_CHANNEL = "28011";
        static $paymentNotifyUrl = "https://apk.paisawin.app/payment/paymentNotification.php";
        static $withdrawNotifyUrl = "https://apk.paisawin.app/payment/withdrawNotification.php";

        static $mchId = "2m025938";
        static $key = "e159b4297140425bbf00c488217e5e3a";

        static $TEST_MODE = false;

        /**
         * Set test mode
         * @param bool $mode
         */
        static function setTestMode($mode) {
            self::$TEST_MODE = $mode;
        }

        /**
         * Initiate payment to xdpay's systems
         * @param number $amount amount to send
         * @param string $orderId merchant order number
         * @return bool|string Returns a JSON encoded string on success or false on failure.
         */
        static function initiatePayment($amount, $orderId) {
            $reqUrl = "https://apis.xdpay168.com/client/collect/create";

            $mchId = Xdpay::$mchId;
            $key = Xdpay::$key;
            $notifyUrl = Xdpay::$paymentNotifyUrl;

            if (Xdpay::$TEST_MODE)
                $channelID = Xdpay::$TEST_CHANNEL;
            else
                $channelID = Xdpay::$INDIAN_COLLECTION_CHANNEL;

             // signing the order
            $signStr = "";

            $signStr = $signStr . "amount=$amount&";
            $signStr = $signStr . "merchant=$mchId&";
            $signStr = $signStr . "notifyUrl=$notifyUrl&";
            $signStr = $signStr . "orderId=$orderId&";
            $signStr = $signStr . "payCode=$channelID&";
            $signStr = $signStr . "key=$key";

            $sign = Xdpay::sign($signStr);

            $postdata=array(
                'merchant'=>$mchId,
                'payCode'=>$channelID,
                'amount'=>$amount,
                'orderId'=>$orderId,
                'notifyUrl'=>$notifyUrl,
                'sign'=>$sign);

            return json_encode(
                json_decode(Xdpay::initCurlRequest($reqUrl, $postdata), true)
            );
        }

        /**
         * Initiate withdrawl from xdpay's systems
         * @param number $amount amount to withdraw
         * @param string $bankAccount Bank/UPI account number
         * @param string $customName Name of the account holder
         * @param string $remark IFSC code of the bank
         * @param string $orderId merchant order number
         * @return bool|string Returns a JSON encoded string on success or `false` on failure.
         */
        static function initiateWithdrawl($amount, $bankAccount, $customName, $remark, $orderId) {
            $reqUrl = "https://apis.xdpay168.com/client/pay/create";

            $mchId = Xdpay::$mchId;
            $key = Xdpay::$key;
            $notifyUrl = Xdpay::$withdrawNotifyUrl;

            if (Xdpay::$TEST_MODE)
                $channelId = Xdpay::$TEST_CHANNEL;
            else
                $channelId = Xdpay::$INDIAN_PAYMENT_CHANNEL;

            // signing the order
            $signStr = "";

            $signStr = $signStr . "amount=$amount&";
            $signStr = $signStr . "bankAccount=$bankAccount&";
            $signStr = $signStr . "customName=$customName&";
            $signStr = $signStr . "merchant=$mchId&";
            $signStr = $signStr . "notifyUrl=$notifyUrl&";
            $signStr = $signStr . "orderId=$orderId&";
            $signStr = $signStr . "payCode=$channelId&";
            $signStr = $signStr . "remark=$remark&";
            $signStr = $signStr . "key=$key";

            $sign = Xdpay::sign($signStr);

            $postdata=array(
                'bankAccount'=>$bankAccount,
                'customName'=>$customName,
                'merchant'=>$mchId,
                'remark'=>$remark,
                'payCode'=>$channelId,
                'amount'=>$amount,
                'orderId'=>$orderId,
                'notifyUrl'=>$notifyUrl,
                'sign'=>$sign);

            return json_encode(
                json_decode(Xdpay::initCurlRequest($reqUrl, $postdata), true)
            );
        }

        private static function sign($data) {
            return md5($data);
        }

        /**
         * Verifies notification callback responses from xdpay's systems
         * @param mixed $data data sent by xdpay's systems as callbacks payload
         * @return bool returns `true` if data is verified `false` if it is not.
         */
        public static function verify($data) {
            $key = Xdpay::$key;

            $platOrderId = $data->platOrderId;
            $orderId = $data->orderId;
            $amount = $data->amount;
            $status = $data->status;

            $signStr = "";

            $signStr = $signStr . "amount=$amount&";
            $signStr = $signStr . "orderId=$orderId&";
            $signStr = $signStr . "platOrderId=$platOrderId&";
            if(isset($data->remark))
                $signStr = $signStr . "remark=$data->remark&";
            if(isset($data->reverse)) {
                if ($data->reverse)
                    $signStr = $signStr . "reverse=true&";
                else
                    $signStr = $signStr . "reverse=false&";
            }
            $signStr = $signStr . "status=$status&";
            $signStr = $signStr . "key=$key";

            $calculated = Xdpay::sign($signStr);

            if($calculated == $data->sign) {
                return true;
            } else {
                return false;
            }
        }

        private static function initCurlRequest($reqUrl, $postdata) {
            $ch = curl_init();

            curl_setopt($ch,CURLOPT_URL,$reqUrl);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_HEADER, false);
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postdata));  
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

            $response=curl_exec($ch);
            curl_close($ch);

            return $response;
        }
    }

    Xdpay::setTestMode(false);
?>