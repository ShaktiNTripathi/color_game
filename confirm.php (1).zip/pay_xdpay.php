<?php
session_start();

require_once "conn.php";
require_once "./xdpay.php";

$am = $_GET['am'];
$user = $_GET['user'];
$utr = $_POST['utr'];

function random_strings($length_of_string) {
    // String of all alphanumeric character
    $str_result = '0123456789AXYZ012345678901234567890123456789';

    // Shuffle the $str_result and returns substring
    // of specified length
    return substr(
        str_shuffle($str_result),
        0,
        $length_of_string
    );
}

$pre = "MGEK";
$r = random_strings(22);

$rand = $pre . $r;

if($_SERVER["REQUEST_METHOD"] == "GET") {
    $sql1 = "INSERT INTO recharge (username, recharge,status,upi,utr,rand) VALUES ('$user', '$am','Failed','apk.xdpay@ybl','$utr','$rand')";

    if ($conn->query($sql1) == TRUE) {
        $xdpay_resp = Xdpay::initiatePayment($am, $rand);

        $xdpay_data = json_decode($xdpay_resp);

        if ($xdpay_data -> code == 200 && $xdpay_data -> success == true) {
            $url = $xdpay_data -> data -> url;

            header("Location: $url");
        } else {
            echo "Payment gateway is down!" . "<br>";
            echo "Error: " . $xdpay_data -> msg . "<br>";
            echo "Error description: " . $xdpay_data -> desc . "<br>";
        }

    } else {
        echo ("Error description: " . $conn->error);
        echo strlen($user) . gettype($user) . $user;
    }
}
